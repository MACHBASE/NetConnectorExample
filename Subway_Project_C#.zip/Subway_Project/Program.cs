﻿using System;
using System.IO;
using Mach.Data.MachClient;
/**********************************************************************************
 * 
 * [ MACHBASE .NET Sample Project ]
 * 
 * You SHOULD check if machNetConnector DLL file is linked successfully.
 * 
 *  - Default location is $(MACHBASE_HOME)\lib\machNetConnector.dll
 *  - If you will run this under Linux/Unix system, 
 *    default location should be ${MACHBASE_HOME}/lib/machNetConnector.dll
 *  - If you already have DLLs which is not located in $(MACHBASE_HOME), 
 *    please link correctly.
 *
 **********************************************************************************/

namespace MachConnectorExample
{
    enum ErrorCheckType
    {
        ERROR_CHECK_YES = 0,
        ERROR_CHECK_WARNING,
        ERROR_CHECK_NO
    }
    class Data
    {
        public string date;
        public string route;
        public string station;
        public double boardings;
        public double alightings;
    }


    class MachConnectorExampleMain
    {
        // CSV 라인 파싱 함수
        private static string[] ParseCsvLine(string line)
        {
            string[] tokens = line.Split(',');
            for (int i = 0; i < tokens.Length; i++)
            {
                // 따옴표로 묶인 문자열 제거
                if (tokens[i].StartsWith("\"") && tokens[i].EndsWith("\""))
                {
                    tokens[i] = tokens[i].Substring(1, tokens[i].Length - 2);
                }
            }
            return tokens;
        }

        internal const string SERVER_HOST = "127.0.0.1";
        internal const int SERVER_PORT = 5656;

        private static void ExecuteQuery(MachConnection aConn, string aQueryString, ErrorCheckType aCheckType)
        {
            using (MachCommand sCommand = new MachCommand(aQueryString, aConn))
            {
                try
                {
                    sCommand.ExecuteNonQuery();
                }
                catch (MachException me)
                {
                    switch (aCheckType)
                    {
                        case ErrorCheckType.ERROR_CHECK_YES:
                            throw me;
                            break;
                        case ErrorCheckType.ERROR_CHECK_WARNING:
                            Console.WriteLine("[WARNING!]");
                            Console.WriteLine("{0}", me.ToString());
                            break;
                        case ErrorCheckType.ERROR_CHECK_NO:
                        default:
                            break;
                    }
                }
            }
        }


        private static void ExecuteAppend(MachConnection aConn)
        {
            using (MachCommand sAppendCommand = new MachCommand(aConn))
            {
                MachAppendWriter sWriter = sAppendCommand.AppendOpen("TAG");
                DateTime sStartTime = DateTime.Now;

                try
                {
                    StreamReader reader = new StreamReader("subway_en.csv");
                    string line = reader.ReadLine(); // 헤더 라인 읽기 (무시)

                    var sList = new List<object>();
                    string transName = "";
                    Data data = new Data();

                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] tokens = ParseCsvLine(line);
                        
                        data.date = tokens[0];
                        data.route = tokens[1];
                        data.station = tokens[2];
                        data.boardings = double.Parse(tokens[3]);
                        data.alightings = double.Parse(tokens[4]);

                        // 변경된 이름 생성 및 데이터 출력 또는 활용
                        transName = data.route + "_" + data.station + "boardings";
                        sList.Add(transName);
                        sList.Add(data.date);
                        sList.Add(data.boardings);
                        sAppendCommand.AppendData(sWriter, sList, "yyyymmdd");
                        sList.Clear();

                        transName = data.route + "_" + data.station + "alightings";
                        sList.Add(transName);
                        sList.Add(data.date);
                        sList.Add(data.alightings);
                        sAppendCommand.AppendData(sWriter, sList, "yyyymmdd");
                        sList.Clear();
                    }

                    reader.Close();
                }
                catch (IOException e)
                {
                    Console.WriteLine(e.Message);
                }

                sAppendCommand.AppendClose(sWriter);

                Console.WriteLine(String.Format("Success Count : {0}", sWriter.SuccessCount));
                Console.WriteLine(String.Format("Elapsed Time : {0}", DateTime.Now.Subtract(sStartTime)));
            }
        }

        static void Main(string[] args)
        {
            //-------------------
            // Connection Open
            //-------------------
            MachConnection sConn = new MachConnection(String.Format("SERVER={0};PORT_NO={1};UID=SYS;PWD=MANAGER", SERVER_HOST, SERVER_PORT));
            sConn.Open();

            // APPEND
            Console.WriteLine("\n==========APPEND==========");
            ExecuteAppend(sConn);
            sConn.Close();

            Console.WriteLine("Press any key to exit.");
            Console.Read();
        }

        internal const string TABLE_NAME = @"TAG";
        internal const string CREATE_QUERY = @"CREATE TAG TABLE TAG (
                                                    name VARCHAR(60) PRIMARY KEY, 
                                                    time DATETIME BASETIME, 
                                                    value DOUBLE SUMMARIZED
                                              ) with rollup;";
        internal const string DROP_QUERY = @"DROP TABLE TAG;";
    }
}
